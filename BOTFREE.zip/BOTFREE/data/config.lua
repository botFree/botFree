do local _ = {
  about_text = "smilebot v1\nAn advanced administration bot based on TG-CLI written in Lua\n\nhttps://github.com/aboskroop/smilebot\n\nAdmins\n@iwals [Founder]\n@imandaneshi [Developer]\n@POTUS [Developer]\n@seyedan25 [Manager]\n@aRandomStranger [Admin]\n\nSpecial thanks to\nawkward_potato\nSiyanew\ntopkecleon\nVamptacus\n\nOur channels\n@teleseedch [English]\n@iranseed [persian]\n\nOur website \nhttp://teleseed.seedteam.org/\n",
  enabled_plugins = {
    "supergroup",
    "help",
    "plugins",
    "addreply",
    "anti_spam",
    "arabic_lock",
    "decoration",
    "broadcast",
    "delete_msgs",
    "hello",
    "fuuny1",
    "fuck_edit",
    "info",
    "me",
    "invite",
    "isup",
    "leave_ban",
    "leave_bot",
    "lock_bot",
    "lock_fwd",
    "lock_sex",
    "run",
    "lock_media",
    "lock_user",
    "mhbs",
    "msg_checks",
    "sticker",
    "writer",
    "say",
    "replay",
    "banhammer",
    "dev",
    "translate",
    "wether",
    "update",
    "info_s",
    "mydev"
  },
  help_text = "",
  help_text_realm = "",
  help_text_super = "",
  moderation = {
    data = "data/moderation.json"
  },
  sudo_users = {
    115124695
  }
}
return _
end
