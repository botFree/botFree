
معلومات مهمه


لتفعيل الحمايه القصوى للروابط فعل ملف * اولا lock_link


لتنصيب البوت ضع الاكواد بلسره * ثانيا

1-/  sudo apt-get update

2-/  sudo apt-get install libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev lua-socket lua-sec lua-expat libevent-dev make unzip git redis-server autoconf g++ libjansson-dev libpython-dev expat libexpat1-dev

3-/  git clone https://github.com/aboskroop/smilebot.git

4-/  cd smilebot

5-/  chmod +x launch.sh

6-/  ./launch.sh install

7-/  ./launch.sh


وحط رقمك وارفع نفسك مطور من الكونفغ 

بعدين افتح ترمنل واكتب 

redis-server

ومبروك عليك السورس

للاستفسار 
@iq_100k
@heelp_bot

قناه البوت
@porgramer2017

# Channel : [porgramer2017 💡 ](https://telegram.me/C9_pro)
